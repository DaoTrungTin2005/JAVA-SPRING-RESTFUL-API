# 🚀 Java Spring RESTful APIs - Xây Dựng Backend với Spring Boot

This is the **starter project** for the **Java Spring RESTful APIs - Xây Dựng Backend với Spring Boot** course by **Hỏi Dân IT**.

---

## 📢 IMPORTANT NOTICE  
This source code is provided **exclusively for enrolled students** in this course.  
❌ **DO NOT UPLOAD this code to GitHub (Public), GitLab, or any other public repository.**  
❌ **DO NOT SHARE this project on forums, Telegram, Discord, or social media.**  
✅ You **can use Git** for personal learning, but **your repository must be PRIVATE**.

💡 **Violators may face:**  
- DMCA takedown requests.  
- Account suspension on learning platforms.  
- Legal action in serious cases.  

📩 For inquiries, contact: **admin@hoidanit.vn**

---

## 📖 How to Use This Project?

===
Môi trường chạy dự án: Java 17

## Về tác giả
Mọi thông tin về Tác giả Hỏi Dân IT, các bạn có thể tìm kiếm tại đây:

Website chính thức: https://hoidanit.vn/

Youtube “Hỏi Dân IT” : https://www.youtube.com/@hoidanit

Tiktok “Hỏi Dân IT” :  https://www.tiktok.com/@hoidanit

Fanpage “Hỏi Dân IT” : https://www.facebook.com/askITwithERIC/

Udemy Hỏi Dân IT: https://www.udemy.com/user/eric-7039/

